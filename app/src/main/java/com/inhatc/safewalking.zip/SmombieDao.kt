package com.inhatc.safewalking

import androidx.room.*
import androidx.lifecycle.LiveData

@Dao
interface SmombieDao {
    @Query("SELECT * FROM smombie_records WHERE date = :date")
    fun getRecordByDate(date: String): SmombieRecord?

    // 1. 일별 조회: 최근 7일 데이터 (기본 차트용)
    @Query("SELECT * FROM smombie_records ORDER BY date DESC LIMIT 7")
    fun getRecent7DaysRecords(): LiveData<List<SmombieRecord>>

    // 2. 주간 조회: 최근 4주(28일) 데이터를 7일 단위로 그룹화하여 합산
    @Query("""
        SELECT strftime('%Y-W%W', date) as date, 
               SUM(totalDangerDuration) as totalDangerDuration, 
               SUM(totalWarningCount) as totalWarningCount 
        FROM smombie_records 
        GROUP BY strftime('%Y-W%W', date) 
        ORDER BY date DESC LIMIT 4
    """)
    fun getWeeklyRecords(): LiveData<List<SmombieRecord>>

    // 3. 월간 조회: 최근 6개월 데이터를 월 단위로 그룹화하여 합산
    @Query("""
        SELECT strftime('%Y-%m', date) as date, 
               SUM(totalDangerDuration) as totalDangerDuration, 
               SUM(totalWarningCount) as totalWarningCount 
        FROM smombie_records 
        GROUP BY strftime('%Y-%m', date) 
        ORDER BY date DESC LIMIT 6
    """)
    fun getMonthlyRecords(): LiveData<List<SmombieRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertOrUpdate(record: SmombieRecord)
}